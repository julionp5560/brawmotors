<?php
declare(strict_types=1);

// Guarda la preferencia de tema (oscuro / alto_contraste) del usuario que
// tiene la sesión iniciada — disponible para cualquier rol (escritorio y
// app móvil), no solo administradores, porque el toggle vive en ambos
// headers.
require_once dirname(__DIR__, 3) . '/includes/guard_api.php';
require_once dirname(__DIR__, 3) . '/config/db.php';

header('Content-Type: application/json; charset=utf-8');

$data = json_decode(file_get_contents('php://input') ?: '{}', true);
$tema = (string)($data['tema'] ?? '');
$tema = $tema === 'alto_contraste' ? 'alto_contraste' : 'oscuro';

$userId = (int)($_SESSION['user']['id'] ?? 0);
if ($userId <= 0) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'error' => 'No autenticado.'], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $pdo = db();
    $st = $pdo->prepare("UPDATE usuarios SET tema = ? WHERE id = ? LIMIT 1");
    $st->execute([$tema, $userId]);

    // Refleja el cambio también en la sesión activa para que el próximo
    // request server-side (data-tema en <html>) ya salga correcto sin
    // esperar a un nuevo login.
    $_SESSION['user']['tema'] = $tema;

    echo json_encode(['ok' => true, 'tema' => $tema], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
