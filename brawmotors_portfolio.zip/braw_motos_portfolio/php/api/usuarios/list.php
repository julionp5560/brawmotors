<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/includes/guard_api_admin.php';
require_once dirname(__DIR__, 3) . '/config/db.php';

header('Content-Type: application/json; charset=utf-8');

try {
  $pdo = db();
  $st = $pdo->query("
    SELECT u.id, u.nombre_completo, u.usuario, u.email, u.telefono, u.rol_id,
           r.nombre AS rol_nombre, u.activo, u.ultimo_acceso, u.fecha_creacion
    FROM usuarios u
    LEFT JOIN roles r ON r.id = u.rol_id
    ORDER BY u.id ASC
  ");
  echo json_encode(['ok' => true, 'data' => $st->fetchAll(PDO::FETCH_ASSOC)], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
