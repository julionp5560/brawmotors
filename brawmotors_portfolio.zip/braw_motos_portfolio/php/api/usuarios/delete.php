<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/includes/guard_api_admin.php';
require_once dirname(__DIR__, 3) . '/config/db.php';

header('Content-Type: application/json; charset=utf-8');

function bad(string $msg, int $code = 400): void {
  http_response_code($code);
  echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE);
  exit;
}

$data = json_decode(file_get_contents('php://input') ?: '{}', true);
$id   = (int)($data['id'] ?? 0);
if ($id <= 0) bad('id requerido.');

$miId = (int)($_SESSION['user']['id'] ?? 0);
if ($id === $miId) bad('No puedes eliminar tu propia cuenta mientras tienes sesión iniciada.');

try {
  $pdo = db();

  $cur = $pdo->prepare("SELECT rol_id, activo FROM usuarios WHERE id = ? LIMIT 1");
  $cur->execute([$id]);
  $curRow = $cur->fetch(PDO::FETCH_ASSOC);
  if (!$curRow) bad('Usuario no encontrado.', 404);

  if ((int)$curRow['rol_id'] === 1 && (int)$curRow['activo'] === 1) {
    $otros = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE rol_id = 1 AND activo = 1 AND id <> ?");
    $otros->execute([$id]);
    if ((int)$otros->fetchColumn() === 0) {
      bad('No puedes eliminar al último administrador activo del sistema.');
    }
  }

  // Intento 1: borrado físico. Si el usuario ya tiene ventas/órdenes/movimientos
  // asociados, la FK lo rechaza y caemos a desactivarlo (soft-delete).
  try {
    $st = $pdo->prepare("DELETE FROM usuarios WHERE id = ? LIMIT 1");
    $st->execute([$id]);
    echo json_encode(['ok' => true, 'mode' => 'hard'], JSON_UNESCAPED_UNICODE);
    exit;
  } catch (Throwable $e) {
    // cae a soft-delete
  }

  $st2 = $pdo->prepare("UPDATE usuarios SET activo = 0 WHERE id = ? LIMIT 1");
  $st2->execute([$id]);
  echo json_encode(['ok' => true, 'mode' => 'soft'], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
