<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/includes/guard_api_admin.php';
require_once dirname(__DIR__, 3) . '/config/db.php';

header('Content-Type: application/json; charset=utf-8');

function bad(string $msg, int $code = 400): void {
  http_response_code($code);
  echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE);
  exit;
}

$data = json_decode(file_get_contents('php://input') ?: '{}', true);
if (!is_array($data)) bad('JSON inválido.');

$id       = (int)($data['id'] ?? 0);
$nombre   = trim((string)($data['nombre_completo'] ?? ''));
$usuario  = trim((string)($data['usuario'] ?? ''));
$email    = trim((string)($data['email'] ?? ''));
$telefono = trim((string)($data['telefono'] ?? ''));
$rol_id   = (int)($data['rol_id'] ?? 0);
$activo   = isset($data['activo']) ? (int)$data['activo'] : 1;
$password = (string)($data['password'] ?? '');

if ($id <= 0)         bad('id requerido.');
if ($nombre === '')   bad('El nombre completo es requerido.');
if ($usuario === '')  bad('El usuario es requerido.');
if ($rol_id <= 0)     bad('Selecciona un rol.');
if ($password !== '' && strlen($password) < 6) bad('La contraseña debe tener al menos 6 caracteres.');

try {
  $pdo = db();

  $chk = $pdo->prepare("SELECT id FROM roles WHERE id = ? LIMIT 1");
  $chk->execute([$rol_id]);
  if (!$chk->fetch()) bad('Rol inválido.');

  $dup = $pdo->prepare("SELECT id FROM usuarios WHERE usuario = ? AND id <> ? LIMIT 1");
  $dup->execute([$usuario, $id]);
  if ($dup->fetch()) bad('Ese nombre de usuario ya existe.');

  // Evitar quedarse sin ningún administrador activo: si este usuario es
  // actualmente admin activo y se le va a quitar el rol o desactivar,
  // verificamos que quede al menos otro admin activo.
  $cur = $pdo->prepare("SELECT rol_id, activo FROM usuarios WHERE id = ? LIMIT 1");
  $cur->execute([$id]);
  $curRow = $cur->fetch(PDO::FETCH_ASSOC);
  if (!$curRow) bad('Usuario no encontrado.', 404);

  $eraAdminActivo = ((int)$curRow['rol_id'] === 1 && (int)$curRow['activo'] === 1);
  $dejaDeSerAdminActivo = ($rol_id !== 1 || $activo !== 1);

  if ($eraAdminActivo && $dejaDeSerAdminActivo) {
    $otros = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE rol_id = 1 AND activo = 1 AND id <> ?");
    $otros->execute([$id]);
    if ((int)$otros->fetchColumn() === 0) {
      bad('No puedes quitar el último administrador activo del sistema.');
    }
  }

  if ($password !== '') {
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $st = $pdo->prepare("
      UPDATE usuarios
      SET nombre_completo = ?, usuario = ?, PASSWORD = ?, email = ?, telefono = ?, rol_id = ?, activo = ?
      WHERE id = ? LIMIT 1
    ");
    $st->execute([$nombre, $usuario, $hash, $email ?: null, $telefono ?: null, $rol_id, $activo, $id]);
  } else {
    $st = $pdo->prepare("
      UPDATE usuarios
      SET nombre_completo = ?, usuario = ?, email = ?, telefono = ?, rol_id = ?, activo = ?
      WHERE id = ? LIMIT 1
    ");
    $st->execute([$nombre, $usuario, $email ?: null, $telefono ?: null, $rol_id, $activo, $id]);
  }

  echo json_encode(['ok' => true], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => 'Error al actualizar usuario', 'detail' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
