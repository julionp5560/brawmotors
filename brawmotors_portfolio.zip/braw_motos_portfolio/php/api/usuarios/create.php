<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/includes/guard_api_admin.php';
require_once dirname(__DIR__, 3) . '/config/db.php';

header('Content-Type: application/json; charset=utf-8');

function bad(string $msg, int $code = 400): void {
  http_response_code($code);
  echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE);
  exit;
}

$data = json_decode(file_get_contents('php://input') ?: '{}', true);
if (!is_array($data)) bad('JSON inválido.');

$nombre   = trim((string)($data['nombre_completo'] ?? ''));
$usuario  = trim((string)($data['usuario'] ?? ''));
$email    = trim((string)($data['email'] ?? ''));
$telefono = trim((string)($data['telefono'] ?? ''));
$rol_id   = (int)($data['rol_id'] ?? 0);
$activo   = isset($data['activo']) ? (int)$data['activo'] : 1;
$password = (string)($data['password'] ?? '');

if ($nombre === '')   bad('El nombre completo es requerido.');
if ($usuario === '')  bad('El usuario es requerido.');
if ($rol_id <= 0)     bad('Selecciona un rol.');
if (strlen($password) < 6) bad('La contraseña debe tener al menos 6 caracteres.');

try {
  $pdo = db();

  $chk = $pdo->prepare("SELECT id FROM roles WHERE id = ? LIMIT 1");
  $chk->execute([$rol_id]);
  if (!$chk->fetch()) bad('Rol inválido.');

  $dup = $pdo->prepare("SELECT id FROM usuarios WHERE usuario = ? LIMIT 1");
  $dup->execute([$usuario]);
  if ($dup->fetch()) bad('Ese nombre de usuario ya existe.');

  $hash = password_hash($password, PASSWORD_DEFAULT);

  $st = $pdo->prepare("
    INSERT INTO usuarios (nombre_completo, usuario, PASSWORD, email, telefono, rol_id, activo)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  ");
  $st->execute([$nombre, $usuario, $hash, $email ?: null, $telefono ?: null, $rol_id, $activo]);

  echo json_encode(['ok' => true, 'id' => (int)$pdo->lastInsertId()], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => 'Error al crear usuario', 'detail' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
