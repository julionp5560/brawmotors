<?php
declare(strict_types=1);

require_once __DIR__ . "/../../../includes/guard_api_admin.php";
require_once __DIR__ . "/../../../config/db.php";

header("Content-Type: application/json; charset=utf-8");

function bad(string $m, int $c = 400): void {
  http_response_code($c);
  echo json_encode(["ok" => false, "error" => $m], JSON_UNESCAPED_UNICODE);
  exit;
}

try {
  $pdo = db();
  $d = json_decode(file_get_contents("php://input") ?: "{}", true);
  if (!is_array($d)) bad("JSON inválido.");

  $id = (int)($d["id"] ?? 0);
  if ($id <= 0) bad("ID inválido.");

  $sku = trim((string)($d["sku"] ?? ""));
  $nombre = trim((string)($d["nombre"] ?? ""));
  if ($nombre === "") bad("Falta nombre.");

  $categoria_id = (int)($d["categoria_id"] ?? 0);
  $costo = (float)($d["costo"] ?? 0);
  $precio = (float)($d["precio"] ?? 0);
  $stock_minimo = (int)($d["stock_minimo"] ?? 0);
  $activo = (int)($d["activo"] ?? 1);

  // No tocamos stock_actual aquí (tu UI lo mueve por movimientos)
  $sql = "
    UPDATE productos
    SET
      sku = :sku,
      nombre = :nombre,
      costo = :costo,
      precio = :precio,
      categoria_id = :categoria_id,
      stock_minimo = :stock_minimo,
      activo = :activo,
      updated_at = NOW()
    WHERE id = :id
    LIMIT 1
  ";

  $st = $pdo->prepare($sql);
  $st->execute([
    ":id" => $id,
    ":sku" => ($sku !== "" ? $sku : null),
    ":nombre" => $nombre,
    ":costo" => $costo,
    ":precio" => $precio,
    ":categoria_id" => ($categoria_id > 0 ? $categoria_id : null),
    ":stock_minimo" => $stock_minimo,
    ":activo" => $activo,
  ]);

  echo json_encode(["ok" => true], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(["ok" => false, "error" => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
