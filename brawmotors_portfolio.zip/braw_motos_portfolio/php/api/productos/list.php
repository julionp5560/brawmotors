<?php
declare(strict_types=1);

require_once __DIR__ . "/../../../includes/guard_api_admin.php";
require_once __DIR__ . "/../../../config/db.php";

header("Content-Type: application/json; charset=utf-8");

try {
    $pdo = db();

    $q = isset($_GET["q"]) ? trim((string)$_GET["q"]) : "";
    $bajo = isset($_GET["bajo"]) ? (int)$_GET["bajo"] : 0;
    // Igual que en servicios: por default solo activos, pero la pantalla de
    // Inventario puede pedir también los inactivos con ?incluir_inactivos=1
    // para poder verlos y reactivarlos.
    $incluirInactivos = (int)($_GET["incluir_inactivos"] ?? 0) === 1;

    // IMPORTANTE:
    // - El frontend espera: stock_actual y stock_minimo (NO "stock" / "min_stock")
    // - Categorías: tu UI consume php/api/categorias/* (que abajo dejamos sobre categorias_producto)
    //   así que aquí unimos contra categorias_producto para que sea consistente.
    $sql = "
        SELECT
            p.id,
            p.sku,
            p.codigo,
            p.nombre,
            p.costo,
            p.precio,
            p.categoria_id,
            cp.nombre AS categoria,
            p.stock_actual,
            p.stock_minimo,
            p.activo
        FROM productos p
        LEFT JOIN categorias_producto cp ON cp.id = p.categoria_id
        WHERE " . ($incluirInactivos ? "1=1" : "p.activo = 1") . "
    ";

    $params = [];

    if ($q !== "") {
        $sql .= " AND (p.nombre LIKE :q OR p.codigo LIKE :q OR p.sku LIKE :q)";
        $params[":q"] = "%{$q}%";
    }

    if ($bajo === 1) {
        $sql .= " AND p.stock_actual <= p.stock_minimo";
    }

    $sql .= " ORDER BY p.nombre ASC";

    $st = $pdo->prepare($sql);
    $st->execute($params);

    echo json_encode(["ok" => true, "data" => $st->fetchAll()], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(["ok" => false, "error" => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
