<?php
declare(strict_types=1);

require_once __DIR__ . "/../../../includes/guard_api_admin.php";
require_once __DIR__ . "/../../../config/db.php";

header("Content-Type: application/json; charset=utf-8");

function bad(string $m, int $c = 400): void {
    http_response_code($c);
    echo json_encode(["ok" => false, "error" => $m], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $pdo = db();
    $d = json_decode(file_get_contents("php://input") ?: "{}", true);
    if (!is_array($d)) bad("JSON inválido.");

    $sku = trim((string)($d["sku"] ?? ""));
    $nombre = trim((string)($d["nombre"] ?? ""));
    $categoria_id = (int)($d["categoria_id"] ?? 0);

    $costo = (float)($d["costo"] ?? 0);
    $precio = (float)($d["precio"] ?? 0);

    // el frontend manda estos nombres
    $stock_actual = (int)($d["stock_actual"] ?? 0);
    $stock_minimo = (int)($d["stock_minimo"] ?? 0);

    $activo = (int)($d["activo"] ?? 1);

    if ($nombre === "") bad("Falta nombre.");

    // En tu tabla, precio_venta es NOT NULL. Para evitar broncas:
    // - lo igualamos a "precio"
    // - precio_compra lo igualamos a "costo"
    $sql = "
        INSERT INTO productos
            (sku, codigo, nombre, costo, precio, descripcion, categoria_id,
             precio_compra, precio_venta, stock_actual, stock_minimo, activo)
        VALUES
            (:sku, NULL, :nombre, :costo, :precio, NULL, :categoria_id,
             :precio_compra, :precio_venta, :stock_actual, :stock_minimo, :activo)
    ";

    $st = $pdo->prepare($sql);
    $st->execute([
        ":sku" => ($sku !== "" ? $sku : null),
        ":nombre" => $nombre,
        ":costo" => $costo,
        ":precio" => $precio,
        ":categoria_id" => ($categoria_id > 0 ? $categoria_id : null),
        ":precio_compra" => $costo,
        ":precio_venta" => $precio,
        ":stock_actual" => $stock_actual,
        ":stock_minimo" => $stock_minimo,
        ":activo" => $activo,
    ]);

    echo json_encode(["ok" => true, "id" => (int)$pdo->lastInsertId()], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(["ok" => false, "error" => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
