<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

require_once dirname(__DIR__, 3) . '/includes/guard_api.php';
require_once dirname(__DIR__, 3) . '/config/db.php';

function bad(string $msg): void {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE);
  exit;
}

$data = json_decode(file_get_contents('php://input') ?: '{}', true);
$id   = (int)($data['id'] ?? 0);
if ($id <= 0) bad('id requerido.');

try {
  $pdo = db();

  // Intento 1: borrado físico. Si el vehículo ya tiene órdenes de taller
  // asociadas, la FK lo rechaza y caemos a desactivarlo (soft-delete),
  // igual que servicios/productos.
  try {
    $st = $pdo->prepare("DELETE FROM vehiculos WHERE id = ? LIMIT 1");
    $st->execute([$id]);
    echo json_encode(['ok' => true, 'mode' => 'hard'], JSON_UNESCAPED_UNICODE);
    exit;
  } catch (Throwable $e) {
    // cae a soft-delete
  }

  $st2 = $pdo->prepare("UPDATE vehiculos SET activo = 0 WHERE id = ? LIMIT 1");
  $st2->execute([$id]);
  echo json_encode(['ok' => true, 'mode' => 'soft'], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
