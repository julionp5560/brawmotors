<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

require_once dirname(__DIR__, 3) . '/includes/guard_api.php';
require_once dirname(__DIR__, 3) . '/config/db.php';

function bad(string $msg): void {
  http_response_code(400);
  echo json_encode(['ok'=>false,'error'=>$msg], JSON_UNESCAPED_UNICODE);
  exit;
}

$data       = json_decode(file_get_contents('php://input') ?: '{}', true);
$cliente_id = (int)($data['cliente_id'] ?? 0);
$marca      = trim((string)($data['marca']   ?? ''));
$modelo     = trim((string)($data['modelo']  ?? ''));
$anio       = $data['año'] ? (int)$data['año'] : null;
$color      = trim((string)($data['color']   ?? ''));
$placas     = strtoupper(trim((string)($data['placas'] ?? $data['placa'] ?? '')));
$numeroSerie = trim((string)($data['numero_serie'] ?? ''));
$kilometraje = isset($data['kilometraje']) && $data['kilometraje'] !== '' ? (int)$data['kilometraje'] : null;
$notas      = trim((string)($data['notas'] ?? ''));

if ($cliente_id <= 0) bad('cliente_id requerido.');
if (!$marca)          bad('Marca requerida.');

try {
  $pdo = db();
  $st  = $pdo->prepare("INSERT INTO vehiculos (cliente_id, marca, modelo, año, color, placas, numero_serie, kilometraje, notas, activo)
                        VALUES (?,?,?,?,?,?,?,?,?,1)");
  $st->execute([$cliente_id, $marca, $modelo, $anio, $color, $placas, $numeroSerie ?: null, $kilometraje, $notas ?: null]);
  $id = (int)$pdo->lastInsertId();
  echo json_encode(['ok'=>true,'id'=>$id,'marca'=>$marca,'modelo'=>$modelo,'placas'=>$placas], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>$e->getMessage()], JSON_UNESCAPED_UNICODE);
}
