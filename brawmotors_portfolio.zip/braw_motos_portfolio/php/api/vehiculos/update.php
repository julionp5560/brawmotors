<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

require_once dirname(__DIR__, 3) . '/includes/guard_api.php';
require_once dirname(__DIR__, 3) . '/config/db.php';

function bad(string $msg): void {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE);
  exit;
}

$data       = json_decode(file_get_contents('php://input') ?: '{}', true);
$id         = (int)($data['id'] ?? 0);
$marca      = trim((string)($data['marca']  ?? ''));
$modelo     = trim((string)($data['modelo'] ?? ''));
$anio       = ($data['año'] ?? '') !== '' ? (int)$data['año'] : null;
$color      = trim((string)($data['color']  ?? ''));
$placas     = strtoupper(trim((string)($data['placas'] ?? $data['placa'] ?? '')));
$numeroSerie = trim((string)($data['numero_serie'] ?? ''));
$kilometraje = isset($data['kilometraje']) && $data['kilometraje'] !== '' ? (int)$data['kilometraje'] : null;
$notas      = trim((string)($data['notas'] ?? ''));
$activo     = isset($data['activo']) ? (int)$data['activo'] : 1;

if ($id <= 0) bad('id requerido.');
if (!$marca) bad('Marca requerida.');

try {
  $pdo = db();
  $st = $pdo->prepare("
    UPDATE vehiculos
    SET marca = ?, modelo = ?, año = ?, color = ?, placas = ?, numero_serie = ?, kilometraje = ?, notas = ?, activo = ?
    WHERE id = ?
    LIMIT 1
  ");
  $st->execute([$marca, $modelo, $anio, $color, $placas, $numeroSerie ?: null, $kilometraje, $notas ?: null, $activo, $id]);
  echo json_encode(['ok' => true], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
