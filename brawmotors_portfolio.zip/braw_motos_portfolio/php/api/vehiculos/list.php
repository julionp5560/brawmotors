<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

require_once dirname(__DIR__, 3) . '/includes/guard_api.php';
require_once dirname(__DIR__, 3) . '/config/db.php';

try {
  $pdo        = db();
  $cliente_id = (int)($_GET['cliente_id'] ?? 0);

  if ($cliente_id <= 0) {
    echo json_encode(['ok'=>true,'data'=>[]], JSON_UNESCAPED_UNICODE);
    exit;
  }

  $soloActivos = isset($_GET['activo']) && $_GET['activo'] === '1';
  $sql = "
    SELECT id, cliente_id, marca, modelo, año, color, placas, placas AS placa,
           numero_serie, kilometraje, notas, activo
    FROM vehiculos
    WHERE cliente_id = ?
  " . ($soloActivos ? " AND activo = 1 " : "") . "
    ORDER BY id DESC
    LIMIT 20
  ";
  $st = $pdo->prepare($sql);
  $st->execute([$cliente_id]);

  echo json_encode(['ok'=>true,'data'=>$st->fetchAll(PDO::FETCH_ASSOC)], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>$e->getMessage()], JSON_UNESCAPED_UNICODE);
}
