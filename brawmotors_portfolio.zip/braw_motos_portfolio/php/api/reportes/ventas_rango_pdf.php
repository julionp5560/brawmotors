<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/includes/guard_api.php';
require_once dirname(__DIR__, 3) . '/config/db.php';
require_once dirname(__DIR__, 3) . '/includes/functions.php';
require_once dirname(__DIR__, 3) . '/includes/SimplePdf.php';
require_once dirname(__DIR__, 3) . '/includes/backup.php';

// Reporte financiero: nunca para roles operarios (Mecánico/Lavador).
if (is_operario()) {
    http_response_code(403);
    echo 'No autorizado.';
    exit;
}

$desde = preg_replace('/[^0-9\-]/', '', (string)($_GET['desde'] ?? ''));
$hasta = preg_replace('/[^0-9\-]/', '', (string)($_GET['hasta'] ?? ''));
if ($desde === '') $desde = date('Y-m-d', strtotime('-6 days'));
if ($hasta === '') $hasta = date('Y-m-d');
if ($desde > $hasta) { [$desde, $hasta] = [$hasta, $desde]; }

$pdo = db();

$st = $pdo->prepare("
  SELECT id, folio, fecha, cliente_nombre, metodo_pago, total, estado
  FROM ventas
  WHERE DATE(COALESCE(fecha, created_at)) BETWEEN ? AND ?
    AND COALESCE(estado,'pagada') <> 'cancelada'
  ORDER BY fecha ASC
");
$st->execute([$desde, $hasta]);
$ventas = $st->fetchAll(PDO::FETCH_ASSOC);

$total = 0.0;
foreach ($ventas as $v) $total += (float)$v['total'];

global $NEGOCIO_NOMBRE;
$negocio = (string)($NEGOCIO_NOMBRE ?? 'BRAW MOTORS');

$pdf = new SimplePdf();
$pdf->addPage(215.9, 279.4, 14); // Carta
$pdf->lineHeight = 5.6;

$pdf->setFont('CB', 15);
$pdf->writeLine($negocio, 'center');
$pdf->setFont('C', 10);
$pdf->writeLine('Ventas del ' . $desde . ' al ' . $hasta, 'center');
$pdf->skip(2);
$pdf->hr();

// Columnas (mm desde el margen izquierdo). "2026-08-03 11:39" (16 chars) a
// 8.5pt Courier mide ~28.8mm, así que Folio necesita arrancar después de
// eso con margen — un ancho optimista aquí es justo lo que causa traslapes.
$colFecha = 0; $colFolio = 34; $colCliente = 70; $colMetodo = 128; $colTotal = 188;

$pdf->setFont('CB', 8.5);
$pdf->cols([
    ['Fecha', $colFecha, 'left'],
    ['Folio', $colFolio, 'left'],
    ['Cliente', $colCliente, 'left'],
    ['Método', $colMetodo, 'left'],
    ['Total', $colTotal, 'right'],
]);
$pdf->hr(false);

$pdf->setFont('C', 8.5);
if (!$ventas) {
    $pdf->writeLine('Sin ventas en este rango de fechas.');
} else {
    foreach ($ventas as $v) {
        $fecha = substr((string)$v['fecha'], 0, 16);
        $cliente = mb_substr((string)$v['cliente_nombre'], 0, 26);
        $pdf->cols([
            [$fecha, $colFecha, 'left'],
            [(string)$v['folio'], $colFolio, 'left'],
            [$cliente, $colCliente, 'left'],
            [(string)$v['metodo_pago'], $colMetodo, 'left'],
            [respaldo_money((float)$v['total']), $colTotal, 'right'],
        ]);
    }
}

$pdf->hr();
$pdf->setFont('CB', 10.5);
$pdf->row('# Ventas: ' . count($ventas), respaldo_money($total));

$pdf->skip(6);
$pdf->setFont('C', 8);
$pdf->writeLine('Generado el ' . date('Y-m-d H:i'), 'right');

$bytes = $pdf->output();

try {
    $dir = respaldo_carpeta_base() . '/reportes/' . date('Y-m');
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    @file_put_contents($dir . '/ventas_' . $desde . '_a_' . $hasta . '.pdf', $bytes);
} catch (Throwable $e) {
    error_log('ventas_rango_pdf backup: ' . $e->getMessage());
}

header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="ventas_' . $desde . '_a_' . $hasta . '.pdf"');
header('Content-Length: ' . strlen($bytes));
echo $bytes;
