<?php
declare(strict_types=1);

require_once __DIR__ . "/../../../includes/guard_api_admin.php";
require_once __DIR__ . "/../../../config/db.php";

header('Content-Type: application/json; charset=utf-8');

try {
  $pdo = db();

  $hoy = date('Y-m-d');
  $desde = preg_replace('/[^0-9\-]/', '', (string)($_GET['desde'] ?? ''));
  $hasta = preg_replace('/[^0-9\-]/', '', (string)($_GET['hasta'] ?? ''));

  // Por defecto: últimos 7 días (incluyendo hoy)
  if ($desde === '') $desde = date('Y-m-d', strtotime('-6 days'));
  if ($hasta === '') $hasta = $hoy;

  // Si vienen invertidas, las intercambiamos
  if ($desde > $hasta) { [$desde, $hasta] = [$hasta, $desde]; }

  // Resumen del rango (ventas no canceladas)
  $st = $pdo->prepare("
    SELECT COUNT(*) AS n, COALESCE(SUM(total),0) AS total
    FROM ventas
    WHERE DATE(COALESCE(fecha, created_at)) BETWEEN ? AND ?
      AND COALESCE(estado,'pagada') <> 'cancelada'
  ");
  $st->execute([$desde, $hasta]);
  $sum = $st->fetch(PDO::FETCH_ASSOC) ?: ['n' => 0, 'total' => 0];

  // Órdenes de taller entregadas dentro del rango (también cuentan como ingreso)
  $stOt = $pdo->prepare("
    SELECT COUNT(*) AS n, COALESCE(SUM(total),0) AS total
    FROM ordenes_trabajo
    WHERE DATE(fecha_entrega) BETWEEN ? AND ?
      AND estado = 'entregado'
  ");
  $stOt->execute([$desde, $hasta]);
  $sumOt = $stOt->fetch(PDO::FETCH_ASSOC) ?: ['n' => 0, 'total' => 0];

  // Top servicios/productos vendidos en el rango
  $st2 = $pdo->prepare("
    SELECT d.descripcion,
           SUM(d.cantidad) AS qty,
           COALESCE(SUM(d.importe),0) AS total
    FROM venta_detalle d
    JOIN ventas v ON v.id = d.venta_id
    WHERE DATE(COALESCE(v.fecha, v.created_at)) BETWEEN ? AND ?
      AND COALESCE(v.estado,'pagada') <> 'cancelada'
    GROUP BY d.descripcion
    ORDER BY total DESC
    LIMIT 10
  ");
  $st2->execute([$desde, $hasta]);
  $topServicios = $st2->fetchAll(PDO::FETCH_ASSOC);

  // Top clientes por gasto en el rango (solo ventas con cliente identificado)
  $st3 = $pdo->prepare("
    SELECT
      COALESCE(c.nombre_completo, v.cliente_nombre, 'Sin cliente') AS cliente,
      COUNT(*) AS visitas,
      COALESCE(SUM(v.total),0) AS total
    FROM ventas v
    LEFT JOIN clientes c ON c.id = v.cliente_id
    WHERE DATE(COALESCE(v.fecha, v.created_at)) BETWEEN ? AND ?
      AND COALESCE(v.estado,'pagada') <> 'cancelada'
    GROUP BY cliente
    ORDER BY total DESC
    LIMIT 10
  ");
  $st3->execute([$desde, $hasta]);
  $topClientes = $st3->fetchAll(PDO::FETCH_ASSOC);

  // Serie diaria de ventas (para ver la tendencia día a día)
  $st4 = $pdo->prepare("
    SELECT DATE(COALESCE(fecha, created_at)) AS dia,
           COUNT(*) AS n,
           COALESCE(SUM(total),0) AS total
    FROM ventas
    WHERE DATE(COALESCE(fecha, created_at)) BETWEEN ? AND ?
      AND COALESCE(estado,'pagada') <> 'cancelada'
    GROUP BY dia
    ORDER BY dia ASC
  ");
  $st4->execute([$desde, $hasta]);
  $serie = $st4->fetchAll(PDO::FETCH_ASSOC);

  echo json_encode([
    'ok' => true,
    'desde' => $desde,
    'hasta' => $hasta,
    'summary' => [
      'ventas_n' => (int)$sum['n'],
      'ventas_total' => (float)$sum['total'],
      'taller_n' => (int)$sumOt['n'],
      'taller_total' => (float)$sumOt['total'],
      'total_general' => (float)$sum['total'] + (float)$sumOt['total'],
    ],
    'top_servicios' => $topServicios,
    'top_clientes' => $topClientes,
    'serie_diaria' => $serie,
  ], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => 'Error al generar reporte', 'detail' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
