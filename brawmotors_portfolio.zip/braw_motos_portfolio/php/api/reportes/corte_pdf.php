<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/includes/guard_api.php';
require_once dirname(__DIR__, 3) . '/config/db.php';
require_once dirname(__DIR__, 3) . '/includes/functions.php';
require_once dirname(__DIR__, 3) . '/includes/SimplePdf.php';
require_once dirname(__DIR__, 3) . '/includes/backup.php';

// Reporte financiero: nunca para roles operarios (Mecánico/Lavador).
if (is_operario()) {
    http_response_code(403);
    echo 'No autorizado.';
    exit;
}

$date = $_GET['date'] ?? date('Y-m-d');
$date = preg_replace('/[^0-9\-]/', '', (string)$date);
if ($date === '') $date = date('Y-m-d');

$pdo = db();

$st = $pdo->prepare("
  SELECT COUNT(*) AS n_ventas, COALESCE(SUM(subtotal),0) AS subtotal,
         COALESCE(SUM(iva),0) AS iva, COALESCE(SUM(total),0) AS total
  FROM ventas
  WHERE DATE(COALESCE(fecha, created_at)) = ?
    AND COALESCE(estado,'pagada') <> 'cancelada'
");
$st->execute([$date]);
$r = $st->fetch(PDO::FETCH_ASSOC) ?: ['n_ventas' => 0, 'subtotal' => 0, 'iva' => 0, 'total' => 0];

$st2 = $pdo->prepare("
  SELECT LOWER(COALESCE(metodo_pago,'efectivo')) AS metodo_pago, COUNT(*) AS n, COALESCE(SUM(total),0) AS total
  FROM ventas
  WHERE DATE(COALESCE(fecha, created_at)) = ?
    AND COALESCE(estado,'pagada') <> 'cancelada'
  GROUP BY LOWER(COALESCE(metodo_pago,'efectivo'))
");
$st2->execute([$date]);
$metodos = ['efectivo' => ['n' => 0, 'total' => 0], 'tarjeta' => ['n' => 0, 'total' => 0], 'transferencia' => ['n' => 0, 'total' => 0]];
foreach ($st2->fetchAll(PDO::FETCH_ASSOC) as $x) {
    $m = (string)$x['metodo_pago'];
    if (isset($metodos[$m])) $metodos[$m] = ['n' => (int)$x['n'], 'total' => (float)$x['total']];
}

$st3 = $pdo->prepare("
  SELECT COUNT(*) AS n_canceladas, COALESCE(SUM(total),0) AS total_cancelado
  FROM ventas
  WHERE DATE(COALESCE(fecha, created_at)) = ? AND COALESCE(estado,'pagada') = 'cancelada'
");
$st3->execute([$date]);
$can = $st3->fetch(PDO::FETCH_ASSOC) ?: ['n_canceladas' => 0, 'total_cancelado' => 0];

global $NEGOCIO_NOMBRE;
$negocio = (string)($NEGOCIO_NOMBRE ?? 'BRAW MOTORS');

$pdf = new SimplePdf();
$pdf->addPage(148, 210, 14); // A5, cómodo para un corte de un solo día
$pdf->lineHeight = 6;

$pdf->setFont('CB', 15);
$pdf->writeLine($negocio, 'center');
$pdf->setFont('C', 10);
$pdf->writeLine('Corte de caja — ' . $date, 'center');
$pdf->skip(2);
$pdf->hr();

$pdf->setFont('CB', 10);
$pdf->writeLine('Ventas del día (pagadas)');
$pdf->setFont('C', 9.5);
$pdf->row('# Ventas:', (string)(int)$r['n_ventas']);
$pdf->row('Subtotal:', respaldo_money((float)$r['subtotal']));
$pdf->row('IVA:', respaldo_money((float)$r['iva']));
$pdf->setFont('CB', 10.5);
$pdf->row('TOTAL:', respaldo_money((float)$r['total']));
$pdf->hr();

$pdf->setFont('CB', 10);
$pdf->writeLine('Desglose por método de pago');
$pdf->setFont('CB', 9);
$pdf->cols([['Método', 0, 'left'], ['# Ventas', 55, 'right'], ['Total', 90, 'right']]);
$pdf->hr(false);
$pdf->setFont('C', 9.5);
$etiquetas = ['efectivo' => 'Efectivo', 'tarjeta' => 'Tarjeta', 'transferencia' => 'Transferencia'];
foreach ($etiquetas as $k => $label) {
    $m = $metodos[$k];
    $pdf->cols([[$label, 0, 'left'], [(string)$m['n'], 55, 'right'], [respaldo_money((float)$m['total']), 90, 'right']]);
}
$pdf->hr();

$pdf->setFont('CB', 10);
$pdf->writeLine('Canceladas (no incluidas en el total)');
$pdf->setFont('C', 9.5);
$pdf->row('# Canceladas:', (string)(int)$can['n_canceladas']);
$pdf->row('Monto:', respaldo_money((float)$can['total_cancelado']));

$pdf->skip(6);
$pdf->setFont('C', 8);
$pdf->writeLine('Generado el ' . date('Y-m-d H:i'), 'right');

$bytes = $pdf->output();

// Copia de respaldo automática, igual que con las ventas individuales.
try {
    $dir = respaldo_carpeta_base() . '/reportes/' . date('Y-m', strtotime($date) ?: time());
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    @file_put_contents($dir . '/corte_' . $date . '.pdf', $bytes);
} catch (Throwable $e) {
    error_log('corte_pdf backup: ' . $e->getMessage());
}

header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="corte_' . $date . '.pdf"');
header('Content-Length: ' . strlen($bytes));
echo $bytes;
