<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

require_once dirname(__DIR__, 3) . '/includes/guard_api.php';
require_once dirname(__DIR__, 3) . '/config/db.php';
require_once dirname(__DIR__, 3) . '/includes/functions.php';
require_once dirname(__DIR__, 3) . '/includes/citas_activacion.php';
$pdo = db();

// Convierte en orden real cualquier cita de taller cuyo día ya llegó, antes
// de listar (ver includes/citas_activacion.php).
activar_citas_del_dia($pdo, 'taller');


function respond(int $code, array $payload): void {
  http_response_code($code);
  echo json_encode($payload, JSON_UNESCAPED_UNICODE);
  exit;
}

try {
  if (!isset($pdo) || !($pdo instanceof PDO)) {
    respond(500, ["ok" => false, "error" => "No hay conexión PDO (\$pdo). Revisa database.php"]);
  }

  // Filtros por querystring
  $estado = isset($_GET['estado']) ? trim((string)$_GET['estado']) : '';
  $tipo   = isset($_GET['tipo']) ? trim((string)$_GET['tipo']) : '';
  $cliente_id = isset($_GET['cliente_id']) ? (int)$_GET['cliente_id'] : 0;
  $folio = isset($_GET['folio']) ? trim((string)$_GET['folio']) : '';
  $q = isset($_GET['q']) ? trim((string)$_GET['q']) : '';

  $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 50;
  $offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;

  if ($limit < 1) $limit = 50;
  if ($limit > 200) $limit = 200;
  if ($offset < 0) $offset = 0;

  $where = [];
  $params = [];

  if ($estado !== '') {
    $where[] = "ot.estado = :estado";
    $params[":estado"] = $estado;
  }

  // tipo es opcional (si aún no existe columna tipo, esto podría fallar)
  // Lo manejamos intentando usarla; si falla, te digo abajo cómo solucionarlo.
  $useTipo = ($tipo !== '');
  if ($useTipo) {
    $where[] = "ot.tipo = :tipo";
    $params[":tipo"] = $tipo;
  }

  if ($cliente_id > 0) {
    $where[] = "ot.cliente_id = :cliente_id";
    $params[":cliente_id"] = $cliente_id;
  }

  if ($folio !== '') {
    $where[] = "ot.folio = :folio";
    $params[":folio"] = $folio;
  }

  if ($q !== '') {
    $where[] = "(ot.folio LIKE :q OR c.nombre_completo LIKE :q)";
    $params[":q"] = "%" . $q . "%";
  }

  // ot.tipo puede no existir todavía en algunas instalaciones (ver crear.php,
  // que ya maneja esto con un try/catch al guardarlo). Para no tronar aquí,
  // primero intentamos con la columna; si MySQL dice "Unknown column ot.tipo",
  // reintentamos sin ella y regresamos 'taller' por default (que es lo único
  // que se guarda en ordenes_trabajo; autolavado vive en su propia tabla).
  $buildSql = function (bool $withTipo) use ($where, $useTipo) {
    $select = $withTipo ? "ot.tipo,\n      " : "";
    $whereParts = $where;
    if (!$withTipo && $useTipo) {
      // Sin columna tipo no podemos filtrar por ella; la quitamos del WHERE.
      $whereParts = array_values(array_filter($whereParts, fn($w) => strpos($w, 'ot.tipo') === false));
    }
    $whereSqlLocal = $whereParts ? ("WHERE " . implode(" AND ", $whereParts)) : "";
    return "
    SELECT
      ot.id,
      ot.folio,
      {$select}ot.estado,
      ot.pagado,
      ot.descripcion_problema,
      ot.diagnostico,
      ot.fecha_entrada,
      ot.fecha_estimada_entrega,
      ot.fecha_entrega,
      ot.kilometraje_entrada,
      ot.total,
      ot.notas,
      c.id AS cliente_id,
      c.nombre_completo AS cliente_nombre,
      v.id AS vehiculo_id,
      CONCAT_WS(' ', v.marca, v.modelo, v.año) AS vehiculo_desc,
      u.id AS usuario_id,
      u.nombre_completo AS usuario_nombre,
      (SELECT COUNT(*) FROM orden_extras oe WHERE oe.orden_id = ot.id AND oe.estado = 'pendiente') AS extras_pendientes
    FROM ordenes_trabajo ot
    INNER JOIN clientes c ON c.id = ot.cliente_id
    LEFT JOIN vehiculos v ON v.id = ot.vehiculo_id
    LEFT JOIN usuarios u ON u.id = ot.usuario_id
    $whereSqlLocal
    ORDER BY ot.id DESC
    LIMIT :limit OFFSET :offset
  ";
  };

  try {
    $sql = $buildSql(true);
    $stmt = $pdo->prepare($sql);
    foreach ($params as $k => $v) {
      if (strpos($k, ':tipo') === 0) continue; // se filtra abajo si aplica
      $stmt->bindValue($k, $v);
    }
    if ($useTipo) $stmt->bindValue(":tipo", $tipo);
    $stmt->bindValue(":limit", $limit, PDO::PARAM_INT);
    $stmt->bindValue(":offset", $offset, PDO::PARAM_INT);
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
  } catch (Throwable $e) {
    if (stripos($e->getMessage(), 'tipo') === false) throw $e;

    // Columna tipo no existe todavía: reintentar sin ella.
    $sql = $buildSql(false);
    $stmt = $pdo->prepare($sql);
    foreach ($params as $k => $v) {
      if (strpos($k, ':tipo') === 0) continue;
      $stmt->bindValue($k, $v);
    }
    $stmt->bindValue(":limit", $limit, PDO::PARAM_INT);
    $stmt->bindValue(":offset", $offset, PDO::PARAM_INT);
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as &$row) { $row['tipo'] = 'taller'; }
    unset($row);
  }

  // Rol Mecánico (app móvil): nunca exponer montos.
  if (is_operario()) {
    foreach ($rows as &$row) {
      unset($row['total']);
    }
    unset($row);
  }

  foreach ($rows as &$row) {
    $row['pagado'] = (int)($row['pagado'] ?? 0);
    $row['extras_pendientes'] = (int)($row['extras_pendientes'] ?? 0);
  }
  unset($row);

  respond(200, ["ok" => true, "data" => $rows]);

} catch (Throwable $e) {
  respond(500, [
    "ok" => false,
    "error" => "Error al listar ordenes",
    "detail" => $e->getMessage()
  ]);
}
