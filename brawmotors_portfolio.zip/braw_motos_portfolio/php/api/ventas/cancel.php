<?php
declare(strict_types=1);

require_once __DIR__ . "/../../../includes/guard_api.php";
require_once __DIR__ . "/../../../config/db.php";

header('Content-Type: application/json; charset=utf-8');

function bad(string $msg, int $code=400): void {
  http_response_code($code);
  echo json_encode(['ok'=>false,'error'=>$msg], JSON_UNESCAPED_UNICODE);
  exit;
}

$user = $_SESSION['user'] ?? null;
if (!$user) bad("No autenticado.", 401);

$raw = file_get_contents("php://input");
$data = json_decode($raw ?: "{}", true);
if (!is_array($data)) bad("JSON inválido.");

$id = (int)($data['id'] ?? 0);
$motivo = trim((string)($data['motivo'] ?? ''));

if ($id <= 0) bad("id inválido.");
if ($motivo === '') bad("Falta motivo.");
if (mb_strlen($motivo) > 255) bad("Motivo demasiado largo (máx 255).");

try {
  $pdo = db();

  // Verificar existe y no está cancelada
  $st = $pdo->prepare("SELECT id, estado FROM ventas WHERE id=? LIMIT 1");
  $st->execute([$id]);
  $v = $st->fetch(PDO::FETCH_ASSOC);

  if (!$v) bad("Venta no encontrada.", 404);
  if (($v['estado'] ?? '') === 'cancelada') bad("La venta ya está cancelada.");

  $uid = (int)$user['id'];

  $up = $pdo->prepare("
    UPDATE ventas
    SET estado='cancelada',
        cancelada_at=NOW(),
        cancelada_por=?,
        motivo_cancelacion=?
    WHERE id=?
    LIMIT 1
  ");
  $up->execute([$uid, $motivo, $id]);

  echo json_encode(['ok'=>true], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>$e->getMessage()], JSON_UNESCAPED_UNICODE);
}
