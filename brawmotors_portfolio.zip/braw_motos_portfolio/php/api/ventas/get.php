<?php
declare(strict_types=1);

require_once __DIR__ . "/../../../includes/guard_api.php";
require_once __DIR__ . "/../../../config/db.php";

header('Content-Type: application/json; charset=utf-8');

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'id inválido'], JSON_UNESCAPED_UNICODE);
  exit;
}

try {
  $pdo = db();

  $st = $pdo->prepare("SELECT id, folio, fecha, cliente_nombre, metodo_pago, subtotal, iva_rate, iva, total, notas, estado, usuario_id
                       FROM ventas WHERE id=? LIMIT 1");
  $st->execute([$id]);
  $venta = $st->fetch(PDO::FETCH_ASSOC);

  if (!$venta) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'error' => 'Venta no encontrada'], JSON_UNESCAPED_UNICODE);
    exit;
  }

  $dt = $pdo->prepare("SELECT tipo_item, item_id, descripcion, cantidad, precio_unitario, importe
                       FROM venta_detalle WHERE venta_id=? ORDER BY id ASC");
  $dt->execute([$id]);
  $items = $dt->fetchAll(PDO::FETCH_ASSOC);

  echo json_encode(['ok' => true, 'venta' => $venta, 'items' => $items], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
