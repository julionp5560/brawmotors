<?php
declare(strict_types=1);

require_once __DIR__ . "/../../../includes/guard_api.php";
require_once __DIR__ . "/../../../config/db.php";

header('Content-Type: application/json; charset=utf-8');

try {
  $pdo = db();

  // Por default: hoy
  $date = $_GET['date'] ?? date('Y-m-d');
  $date = preg_replace('/[^0-9\-]/', '', (string)$date);

  $st = $pdo->prepare("
    SELECT id, folio, fecha, cliente_nombre, metodo_pago, subtotal, iva, total, estado
    FROM ventas
    WHERE DATE(fecha) = ?
    ORDER BY id DESC
    LIMIT 100
  ");
  $st->execute([$date]);

  $rows = $st->fetchAll(PDO::FETCH_ASSOC);

  echo json_encode(['ok' => true, 'data' => $rows], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
