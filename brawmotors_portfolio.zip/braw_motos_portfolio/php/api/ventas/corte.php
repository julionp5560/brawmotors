<?php
declare(strict_types=1);

require_once __DIR__ . "/../../../includes/guard_api.php";
require_once __DIR__ . "/../../../config/db.php";

header('Content-Type: application/json; charset=utf-8');

try {
  $pdo = db();

  // fecha (YYYY-MM-DD). Default hoy
  $date = $_GET['date'] ?? date('Y-m-d');
  $date = preg_replace('/[^0-9\-]/', '', (string)$date);
  if ($date === '') $date = date('Y-m-d');

  // Totales pagadas (no canceladas)
  $st = $pdo->prepare("
    SELECT
      COUNT(*) AS n_ventas,
      COALESCE(SUM(subtotal),0) AS subtotal,
      COALESCE(SUM(iva),0) AS iva,
      COALESCE(SUM(total),0) AS total
    FROM ventas
    WHERE DATE(COALESCE(fecha, created_at)) = ?
      AND COALESCE(estado,'pagada') <> 'cancelada'
  ");
  $st->execute([$date]);
  $r = $st->fetch(PDO::FETCH_ASSOC) ?: ['n_ventas'=>0,'subtotal'=>0,'iva'=>0,'total'=>0];

  // Desglose por método (pagadas)
  $st2 = $pdo->prepare("
    SELECT
      LOWER(COALESCE(metodo_pago,'efectivo')) AS metodo_pago,
      COUNT(*) AS n,
      COALESCE(SUM(total),0) AS total
    FROM ventas
    WHERE DATE(COALESCE(fecha, created_at)) = ?
      AND COALESCE(estado,'pagada') <> 'cancelada'
    GROUP BY LOWER(COALESCE(metodo_pago,'efectivo'))
  ");
  $st2->execute([$date]);
  $rows = $st2->fetchAll(PDO::FETCH_ASSOC);

  $metodos = [
    'efectivo' => ['n'=>0,'total'=>0],
    'tarjeta' => ['n'=>0,'total'=>0],
    'transferencia' => ['n'=>0,'total'=>0],
  ];
  foreach ($rows as $x) {
    $m = (string)$x['metodo_pago'];
    if (!isset($metodos[$m])) continue;
    $metodos[$m] = ['n'=>(int)$x['n'], 'total'=>(float)$x['total']];
  }

  // Canceladas (solo para info)
  $st3 = $pdo->prepare("
    SELECT
      COUNT(*) AS n_canceladas,
      COALESCE(SUM(total),0) AS total_cancelado
    FROM ventas
    WHERE DATE(COALESCE(fecha, created_at)) = ?
      AND COALESCE(estado,'pagada') = 'cancelada'
  ");
  $st3->execute([$date]);
  $c = $st3->fetch(PDO::FETCH_ASSOC) ?: ['n_canceladas'=>0,'total_cancelado'=>0];

  echo json_encode([
    'ok' => true,
    'date' => $date,
    'pagadas' => [
      'n' => (int)$r['n_ventas'],
      'subtotal' => (float)$r['subtotal'],
      'iva' => (float)$r['iva'],
      'total' => (float)$r['total'],
    ],
    'metodos' => $metodos,
    'canceladas' => [
      'n' => (int)$c['n_canceladas'],
      'total' => (float)$c['total_cancelado'],
    ]
  ], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>$e->getMessage()], JSON_UNESCAPED_UNICODE);
}
