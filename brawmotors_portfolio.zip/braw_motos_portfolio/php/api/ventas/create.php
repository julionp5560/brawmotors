<?php
declare(strict_types=1);

require_once __DIR__ . "/../../../includes/guard_api.php";
require_once __DIR__ . "/../../../config/db.php";
require_once __DIR__ . "/../../../includes/backup.php";

header('Content-Type: application/json; charset=utf-8');

function bad(string $msg, int $code = 400): void {
  http_response_code($code);
  echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE);
  exit;
}

$raw = file_get_contents("php://input");
$data = json_decode($raw ?: "{}", true);
if (!is_array($data)) bad("JSON inválido.");

$user = $_SESSION['user'] ?? null;
if (!$user) bad("No autenticado.", 401);

$cliente = trim((string)($data['cliente'] ?? 'Mostrador'));
$pago = (string)($data['pago'] ?? 'efectivo');
$notas = trim((string)($data['notas'] ?? ''));
$iva_rate = (float)($data['iva_rate'] ?? 0);

if ($cliente === '') $cliente = 'Mostrador';
if (!in_array($pago, ['efectivo','tarjeta','transferencia'], true)) bad("Método de pago inválido.");
if ($iva_rate < 0 || $iva_rate > 100) bad("IVA inválido.");

$items = $data['items'] ?? [];
if (!is_array($items) || count($items) === 0) bad("Sin items.");

try {
  $pdo = db();
  $pdo->beginTransaction();

  // Folio simple (único). Ej: V-20260130-000123
  // OJO: basado en ID real, pero lo definimos después de insertar.
  $usuario_id = (int)$user['id'];

  // Insert placeholder venta
  $st = $pdo->prepare("INSERT INTO ventas (folio, fecha, cliente_nombre, usuario_id, metodo_pago, subtotal, iva_rate, iva, total, notas, estado)
                       VALUES ('TMP', NOW(), ?, ?, ?, 0, ?, 0, 0, ?, 'pagada')");
  $st->execute([$cliente, $usuario_id, $pago, $iva_rate, ($notas !== '' ? $notas : null)]);

  $venta_id = (int)$pdo->lastInsertId();
  $folio = sprintf("V-%s-%06d", date('Ymd'), $venta_id);

  // Update folio ya con ID
  $st = $pdo->prepare("UPDATE ventas SET folio=? WHERE id=?");
  $st->execute([$folio, $venta_id]);

  $subtotal = 0.0;

  // Insert detalle (validamos servicios si vienen con servicio_id)
  $ins = $pdo->prepare("INSERT INTO venta_detalle (venta_id, tipo_item, item_id, descripcion, cantidad, precio_unitario, importe)
                        VALUES (?, ?, ?, ?, ?, ?, ?)");

  $svc = $pdo->prepare("SELECT id, nombre FROM servicios WHERE id=? AND activo=1 LIMIT 1");

  foreach ($items as $it) {
    if (!is_array($it)) continue;

    $servicio_id = isset($it['servicio_id']) ? (int)$it['servicio_id'] : 0;
    $desc = trim((string)($it['desc'] ?? ''));
    $qty = (float)($it['qty'] ?? 1);
    $price = (float)($it['price'] ?? 0);

    if ($qty <= 0) bad("Cantidad inválida.");
    if ($price < 0) bad("Precio inválido.");

    $tipo_item = 'manual';
    $item_id = null;

    if ($servicio_id > 0) {
      $svc->execute([$servicio_id]);
      $row = $svc->fetch(PDO::FETCH_ASSOC);
      if (!$row) bad("Servicio no existe o inactivo (id={$servicio_id}).");
      $tipo_item = 'servicio';
      $item_id = $servicio_id;

      // Si no mandan desc, tomamos el nombre real
      if ($desc === '') $desc = (string)$row['nombre'];
    }

    if ($desc === '') $desc = 'Item';

    $importe = $qty * $price;
    $subtotal += $importe;

    $ins->execute([
      $venta_id,
      $tipo_item,
      $item_id,
      $desc,
      $qty,
      $price,
      $importe
    ]);
  }

  $iva = $subtotal * ($iva_rate / 100.0);
  $total = $subtotal + $iva;

  $up = $pdo->prepare("UPDATE ventas SET subtotal=?, iva=?, total=? WHERE id=?");
  $up->execute([$subtotal, $iva, $total, $venta_id]);

  $pdo->commit();

  // Respaldo en PDF (no debe romper el cobro si falla; ver backup.php).
  guardar_venta_pdf($pdo, $venta_id);

  echo json_encode([
    'ok' => true,
    'venta_id' => $venta_id,
    'folio' => $folio,
    'total' => number_format($total, 2, '.', '')
  ], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
  if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
