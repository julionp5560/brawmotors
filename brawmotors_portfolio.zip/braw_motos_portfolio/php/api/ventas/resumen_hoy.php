<?php
declare(strict_types=1);

require_once __DIR__ . "/../../../includes/guard_api.php";
require_once __DIR__ . "/../../../config/db.php";

header('Content-Type: application/json; charset=utf-8');

try {
  $pdo = db();

  // cuenta ventas del día excepto canceladas (aunque estado sea NULL)
  $st = $pdo->query("
    SELECT
      COUNT(*) AS n_ventas,
      COALESCE(SUM(total),0) AS total_hoy
    FROM ventas
    WHERE DATE(COALESCE(fecha, created_at)) = CURDATE()
      AND COALESCE(estado,'pagada') <> 'cancelada'
  ");
  $r = $st->fetch(PDO::FETCH_ASSOC) ?: ['n_ventas'=>0,'total_hoy'=>0];

  $st2 = $pdo->query("
    SELECT
      LOWER(COALESCE(metodo_pago,'efectivo')) AS metodo_pago,
      COUNT(*) AS n,
      COALESCE(SUM(total),0) AS total
    FROM ventas
    WHERE DATE(COALESCE(fecha, created_at)) = CURDATE()
      AND COALESCE(estado,'pagada') <> 'cancelada'
    GROUP BY LOWER(COALESCE(metodo_pago,'efectivo'))
  ");
  $rows = $st2->fetchAll(PDO::FETCH_ASSOC);

  $corte = [
    'efectivo' => ['n'=>0,'total'=>0],
    'tarjeta' => ['n'=>0,'total'=>0],
    'transferencia' => ['n'=>0,'total'=>0],
  ];

  foreach ($rows as $x) {
    $m = (string)$x['metodo_pago'];
    if (!isset($corte[$m])) continue;
    $corte[$m] = ['n'=>(int)$x['n'], 'total'=>(float)$x['total']];
  }

  echo json_encode([
    'ok' => true,
    'ventas' => [
      'n' => (int)$r['n_ventas'],
      'total' => (float)$r['total_hoy'],
    ],
    'corte' => $corte
  ], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>$e->getMessage()], JSON_UNESCAPED_UNICODE);
}
