<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/includes/guard_api_admin.php';
require_once dirname(__DIR__, 3) . '/config/db.php';

header('Content-Type: application/json; charset=utf-8');

function bad(string $msg, int $code = 400): void {
  http_response_code($code);
  echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE);
  exit;
}

$data = json_decode(file_get_contents('php://input') ?: '{}', true);
if (!is_array($data)) bad('JSON inválido.');

$nombre = trim((string)($data['nombre'] ?? ''));
$descripcion = trim((string)($data['descripcion'] ?? ''));

if ($nombre === '') bad('El nombre del rol es requerido.');

try {
  $pdo = db();

  $dup = $pdo->prepare("SELECT id FROM roles WHERE nombre = ? LIMIT 1");
  $dup->execute([$nombre]);
  if ($dup->fetch()) bad('Ya existe un rol con ese nombre.');

  $st = $pdo->prepare("INSERT INTO roles (nombre, descripcion) VALUES (?, ?)");
  $st->execute([$nombre, $descripcion ?: null]);

  echo json_encode(['ok' => true, 'id' => (int)$pdo->lastInsertId()], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => 'Error al crear rol', 'detail' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
