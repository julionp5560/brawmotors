<?php
declare(strict_types=1);

require_once __DIR__ . "/../../../includes/guard_api.php";
require_once __DIR__ . "/../../../config/db.php";
require_once __DIR__ . "/../../../includes/functions.php";

header('Content-Type: application/json; charset=utf-8');

try {
  $pdo = db();

  $tipo = $_GET['tipo'] ?? '';
  $tipo = in_array($tipo, ['taller', 'autolavado'], true) ? $tipo : '';

  // Por default solo se listan servicios activos (así lo esperan el POS y las
  // apps móviles). La pantalla de administración de Servicios puede pedir
  // también los inactivos con ?incluir_inactivos=1 para poder verlos y
  // reactivarlos — antes no había forma de volver a ver un servicio una vez
  // marcado como inactivo.
  $incluirInactivos = (int)($_GET['incluir_inactivos'] ?? 0) === 1;
  $whereActivo = $incluirInactivos ? "1=1" : "activo = 1";

  // Costo de insumos: se calcula EN VIVO (nunca congelado) a partir del
  // costo actual de cada producto en servicio_insumos, para poder avisar
  // si el precio de venta del servicio ya no lo cubre.
  $costoSub = "(
    SELECT COALESCE(SUM(si.cantidad * p.costo), 0)
    FROM servicio_insumos si
    JOIN productos p ON p.id = si.producto_id
    WHERE si.servicio_id = servicios.id
  ) AS costo_insumos";

  if ($tipo !== '') {
    $st = $pdo->prepare("SELECT id, nombre, descripcion, tipo, precio, precio_min, precio_max, es_personalizado, tiempo_estimado, activo, {$costoSub}
                         FROM servicios
                         WHERE {$whereActivo} AND tipo = ?
                         ORDER BY nombre ASC");
    $st->execute([$tipo]);
  } else {
    $st = $pdo->prepare("SELECT id, nombre, descripcion, tipo, precio, precio_min, precio_max, es_personalizado, tiempo_estimado, activo, {$costoSub}
                         FROM servicios
                         WHERE {$whereActivo}
                         ORDER BY tipo ASC, nombre ASC");
    $st->execute([]);
  }

  $rows = $st->fetchAll(PDO::FETCH_ASSOC);
  foreach ($rows as &$row) { $row['es_personalizado'] = (int)$row['es_personalizado']; }
  unset($row);

  // Rol Mecánico/Lavador (app móvil): nunca exponer el precio de catálogo
  // ni el costo de insumos. precio_min/precio_max SÍ se dejan (solo en
  // autolavado) para que el lavador pueda elegir un monto dentro de un
  // rango permitido al crear el pedido — el dinero en sí lo sigue
  // manejando caja, esto solo evita que el cajero tenga que adivinar.
  if (is_operario()) {
    foreach ($rows as &$row) {
      unset($row['precio']);
      unset($row['costo_insumos']);
      $row['precio_min'] = $row['precio_min'] !== null ? round((float)$row['precio_min'], 2) : null;
      $row['precio_max'] = $row['precio_max'] !== null ? round((float)$row['precio_max'], 2) : null;
    }
    unset($row);
  } else {
    foreach ($rows as &$row) {
      $row['costo_insumos'] = round((float)$row['costo_insumos'], 2);
    }
    unset($row);
  }

  echo json_encode(['ok' => true, 'data' => $rows], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
