<?php
declare(strict_types=1);

require_once dirname(__DIR__, 4) . '/includes/guard_api_admin.php';
require_once dirname(__DIR__, 4) . '/config/db.php';

header('Content-Type: application/json; charset=utf-8');

function bad(string $msg, int $code = 400): void {
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE);
    exit;
}

$data = json_decode(file_get_contents('php://input') ?: '{}', true);
if (!is_array($data)) bad('JSON inválido.');

$servicioId = (int)($data['servicio_id'] ?? 0);
$productoId = (int)($data['producto_id'] ?? 0);
$cantidad = (float)($data['cantidad'] ?? 0);

if ($servicioId <= 0) bad('Falta servicio_id.');
if ($productoId <= 0) bad('Falta producto_id.');
if ($cantidad <= 0) bad('La cantidad debe ser mayor a 0.');

try {
    $pdo = db();

    $chk = $pdo->prepare("SELECT 1 FROM servicios WHERE id = ? LIMIT 1");
    $chk->execute([$servicioId]);
    if (!$chk->fetchColumn()) bad('El servicio no existe.', 404);

    $chk2 = $pdo->prepare("SELECT 1 FROM productos WHERE id = ? LIMIT 1");
    $chk2->execute([$productoId]);
    if (!$chk2->fetchColumn()) bad('El producto no existe.', 404);

    // Upsert: si ya estaba agregado, solo actualiza la cantidad en vez de
    // duplicar o marcar error (más cómodo para editar desde la UI).
    $st = $pdo->prepare("
        INSERT INTO servicio_insumos (servicio_id, producto_id, cantidad)
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE cantidad = VALUES(cantidad)
    ");
    $st->execute([$servicioId, $productoId, $cantidad]);

    echo json_encode(['ok' => true], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
