<?php
declare(strict_types=1);

require_once dirname(__DIR__, 4) . '/includes/guard_api_admin.php';
require_once dirname(__DIR__, 4) . '/config/db.php';

header('Content-Type: application/json; charset=utf-8');

$data = json_decode(file_get_contents('php://input') ?: '{}', true);
$id = (int)($data['id'] ?? 0);

if ($id <= 0) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Falta id.'], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $pdo = db();
    $st = $pdo->prepare("DELETE FROM servicio_insumos WHERE id = ? LIMIT 1");
    $st->execute([$id]);
    echo json_encode(['ok' => true], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
