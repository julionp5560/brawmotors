<?php
declare(strict_types=1);

require_once dirname(__DIR__, 4) . '/includes/guard_api_admin.php';
require_once dirname(__DIR__, 4) . '/config/db.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $servicioId = (int)($_GET['servicio_id'] ?? 0);
    if ($servicioId <= 0) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Falta servicio_id.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $pdo = db();
    $st = $pdo->prepare("
        SELECT si.id, si.producto_id, si.cantidad,
               p.nombre AS producto_nombre, p.costo AS producto_costo, p.activo AS producto_activo
        FROM servicio_insumos si
        JOIN productos p ON p.id = si.producto_id
        WHERE si.servicio_id = ?
        ORDER BY p.nombre ASC
    ");
    $st->execute([$servicioId]);
    $rows = $st->fetchAll(PDO::FETCH_ASSOC);

    $costoTotal = 0.0;
    foreach ($rows as &$r) {
        $r['cantidad'] = (float)$r['cantidad'];
        $r['producto_costo'] = (float)$r['producto_costo'];
        $r['subtotal'] = round($r['cantidad'] * $r['producto_costo'], 2);
        $r['producto_activo'] = (int)$r['producto_activo'];
        $costoTotal += $r['subtotal'];
    }
    unset($r);

    echo json_encode(['ok' => true, 'data' => $rows, 'costo_total' => round($costoTotal, 2)], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
