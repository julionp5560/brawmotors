<?php
declare(strict_types=1);

require_once __DIR__ . "/../../../includes/guard_api_admin.php";
require_once __DIR__ . "/../../../config/db.php";

header('Content-Type: application/json; charset=utf-8');

function bad(string $msg, int $code = 400): void {
  http_response_code($code);
  echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE);
  exit;
}

$raw = file_get_contents("php://input");
$data = json_decode($raw ?: "{}", true);
if (!is_array($data)) bad("JSON inválido.");

$id = (int)($data['id'] ?? 0);
if ($id <= 0) bad("ID inválido.");

$nombre = trim((string)($data['nombre'] ?? ''));
$descripcion = trim((string)($data['descripcion'] ?? ''));
$tipo = (string)($data['tipo'] ?? '');
$precio = (float)($data['precio'] ?? 0);
$tiempo = (int)($data['tiempo_estimado'] ?? 0);
$activo = (int)($data['activo'] ?? 1);

$precioMin = array_key_exists('precio_min', $data) && $data['precio_min'] !== null && $data['precio_min'] !== ''
  ? (float)$data['precio_min'] : null;
$precioMax = array_key_exists('precio_max', $data) && $data['precio_max'] !== null && $data['precio_max'] !== ''
  ? (float)$data['precio_max'] : null;

if ($nombre === '') bad("Falta nombre.");
if (!in_array($tipo, ['taller', 'autolavado'], true)) bad("Tipo inválido (taller/autolavado).");
if ($precio < 0) bad("Precio inválido.");
if ($precioMin !== null && $precioMax !== null && $precioMin > $precioMax) bad("El precio mínimo no puede ser mayor al máximo.");

try {
  $pdo = db();
  $st = $pdo->prepare("
    UPDATE servicios
    SET nombre = ?, descripcion = ?, tipo = ?, precio = ?, precio_min = ?, precio_max = ?, tiempo_estimado = ?, activo = ?
    WHERE id = ?
    LIMIT 1
  ");
  $st->execute([$nombre, $descripcion, $tipo, $precio, $precioMin, $precioMax, $tiempo, $activo, $id]);

  echo json_encode(['ok' => true], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
