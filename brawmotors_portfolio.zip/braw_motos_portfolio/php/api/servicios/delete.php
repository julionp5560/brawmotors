<?php
declare(strict_types=1);

require_once __DIR__ . "/../../../includes/guard_api_admin.php";
require_once __DIR__ . "/../../../config/db.php";

header('Content-Type: application/json; charset=utf-8');

function bad(string $msg, int $code = 400): void {
  http_response_code($code);
  echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE);
  exit;
}

$raw = file_get_contents("php://input");
$data = json_decode($raw ?: "{}", true);
if (!is_array($data)) bad("JSON inválido.");

$id = (int)($data['id'] ?? 0);
if ($id <= 0) bad("ID inválido.");

try {
  $pdo = db();

  // Siempre soft-delete: un servicio nunca se borra físicamente, solo se
  // desactiva. Aunque no tenga ventas/órdenes todavía, borrarlo de verdad
  // rompe el historial el día que sí se use, y además ya no se puede
  // reactivar desde "Ver inactivos". Antes esto borraba físico si el
  // servicio no tenía referencias (bug reportado).
  $st2 = $pdo->prepare("UPDATE servicios SET activo = 0 WHERE id = ? LIMIT 1");
  $st2->execute([$id]);
  echo json_encode(['ok' => true, 'mode' => 'soft'], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
