<?php
declare(strict_types=1);

require_once __DIR__ . "/../../../includes/guard_api_admin.php";
require_once __DIR__ . "/../../../config/db.php";

header('Content-Type: application/json; charset=utf-8');

$raw = file_get_contents("php://input");
$data = json_decode($raw ?: "{}", true);

function bad(string $msg, int $code = 400): void {
  http_response_code($code);
  echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE);
  exit;
}

if (!is_array($data)) bad("JSON inválido.");

$nombre = trim((string)($data['nombre'] ?? ''));
$descripcion = trim((string)($data['descripcion'] ?? ''));
$tipo = (string)($data['tipo'] ?? '');
$precio = (float)($data['precio'] ?? 0);
$tiempo = (int)($data['tiempo_estimado'] ?? 0);
$activo = (int)($data['activo'] ?? 1);

// Rango de precio sugerido (opcional): permite que, en autolavado, el
// lavador elija un monto dentro de este rango al crear el pedido desde
// la app móvil, en vez de un precio fijo único.
$precioMin = array_key_exists('precio_min', $data) && $data['precio_min'] !== null && $data['precio_min'] !== ''
  ? (float)$data['precio_min'] : null;
$precioMax = array_key_exists('precio_max', $data) && $data['precio_max'] !== null && $data['precio_max'] !== ''
  ? (float)$data['precio_max'] : null;

if ($nombre === '') bad("Falta nombre.");
if (!in_array($tipo, ['taller','autolavado'], true)) bad("Tipo inválido (taller/autolavado).");
if ($precio < 0) bad("Precio inválido.");
if ($precioMin !== null && $precioMax !== null && $precioMin > $precioMax) bad("El precio mínimo no puede ser mayor al máximo.");

try {
  $pdo = db();
  $st = $pdo->prepare("INSERT INTO servicios (nombre, descripcion, tipo, precio, precio_min, precio_max, tiempo_estimado, activo, fecha_creacion)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
  $st->execute([$nombre, $descripcion, $tipo, $precio, $precioMin, $precioMax, $tiempo, $activo]);

  echo json_encode(['ok' => true, 'id' => (int)$pdo->lastInsertId()], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
